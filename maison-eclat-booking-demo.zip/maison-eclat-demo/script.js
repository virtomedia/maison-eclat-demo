/* Configure this with the salon's real WhatsApp number before launch.
   International format only: digits, country code included, no + or spaces.
   The X characters below are an intentionally invalid placeholder. */
const SALON_WHATSAPP_NUMBER = "213XXXXXXXXX";
// Keep the two featured photos visible if a particular remote image URL fails.
document.querySelectorAll("img[data-fallback]").forEach(image=>{
  image.addEventListener("error",()=>{
    const fallback=image.dataset.fallback;
    if(fallback && image.src!==fallback){image.src=fallback;image.removeAttribute("data-fallback");}
  },{once:true});
});

const WHATSAPP_MESSAGE = "Bonjour, je souhaite avoir des renseignements sur vos prestations et les disponibilités pour un rendez-vous.";
function makeWhatsAppUrl(){if(!/^\d{8,15}$/.test(SALON_WHATSAPP_NUMBER)||SALON_WHATSAPP_NUMBER.includes("X"))return null;return `https://wa.me/${SALON_WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;}
document.querySelectorAll(".whatsapp-link").forEach(link=>{const url=makeWhatsAppUrl();if(url){link.href=url;link.target="_blank";link.rel="noopener noreferrer";}else{link.href="#contact";link.addEventListener("click",event=>{event.preventDefault();alert("Site de démonstration : renseignez le vrai numéro WhatsApp dans script.js avant la publication.");});}});
const menuToggle=document.querySelector(".menu-toggle"),siteNav=document.querySelector(".site-nav");
menuToggle.addEventListener("click",()=>{const open=menuToggle.getAttribute("aria-expanded")==="true";menuToggle.setAttribute("aria-expanded",String(!open));menuToggle.setAttribute("aria-label",open?"Ouvrir le menu":"Fermer le menu");siteNav.classList.toggle("open",!open);});
siteNav.querySelectorAll("a").forEach(link=>link.addEventListener("click",()=>{menuToggle.setAttribute("aria-expanded","false");menuToggle.setAttribute("aria-label","Ouvrir le menu");siteNav.classList.remove("open");}));
document.getElementById("year").textContent=new Date().getFullYear();
const lightbox=document.getElementById("lightbox"),lightboxImage=lightbox.querySelector("img"),lightboxClose=lightbox.querySelector(".lightbox-close");let lastFocusedElement=null;
function closeLightbox(){lightbox.hidden=true;lightboxImage.src="";if(lastFocusedElement)lastFocusedElement.focus();}
document.querySelectorAll(".gallery-item").forEach(item=>item.addEventListener("click",()=>{lastFocusedElement=item;lightboxImage.src=item.dataset.full;lightboxImage.alt=item.querySelector("img").alt;lightbox.hidden=false;lightboxClose.focus();}));
lightboxClose.addEventListener("click",closeLightbox);lightbox.addEventListener("click",event=>{if(event.target===lightbox)closeLightbox();});document.addEventListener("keydown",event=>{if(event.key==="Escape"&&!lightbox.hidden)closeLightbox();});

// Booking request demo: collects a preferred slot and sends the details by WhatsApp
// when the salon's real number is configured. This static GitHub Pages demo cannot
// check a live calendar or confirm a slot automatically.
const bookingForm=document.getElementById("booking-form");
if(bookingForm){
  const serviceSelect=document.getElementById("booking-service");
  const priceOutput=document.getElementById("booking-price");
  const dateInput=document.getElementById("booking-date");
  const timeSelect=document.getElementById("booking-time");
  const feedback=document.getElementById("booking-feedback");
  const today=new Date();
  const localToday=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
  dateInput.min=localToday;
  serviceSelect.addEventListener("change",()=>{
    const option=serviceSelect.options[serviceSelect.selectedIndex];
    const price=option.dataset.price;
    priceOutput.textContent=price?`À partir de ${Number(price).toLocaleString("fr-FR")} DA`:"Choisissez une prestation";
  });
  dateInput.addEventListener("change",()=>{
    if(!dateInput.value)return;
    const chosen=new Date(`${dateInput.value}T12:00:00`);
    if(chosen.getDay()===5){dateInput.setCustomValidity("Le salon est indiqué comme fermé le vendredi. Veuillez choisir un autre jour.");dateInput.reportValidity();}
    else dateInput.setCustomValidity("");
  });
  bookingForm.addEventListener("submit",event=>{
    event.preventDefault();
    if(!bookingForm.reportValidity())return;
    const chosen=new Date(`${dateInput.value}T12:00:00`);
    if(chosen.getDay()===5){dateInput.setCustomValidity("Le salon est indiqué comme fermé le vendredi. Veuillez choisir un autre jour.");dateInput.reportValidity();return;}
    const data=new FormData(bookingForm);
    const selected=serviceSelect.options[serviceSelect.selectedIndex];
    const dateLabel=chosen.toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
    const note=String(data.get("note")||"").trim();
    const message=["Bonjour Maison Éclat, je souhaite demander un rendez-vous :",`Prestation : ${data.get("service")}`,`Tarif indicatif : à partir de ${Number(selected.dataset.price).toLocaleString("fr-FR")} DA`,`Date souhaitée : ${dateLabel}`,`Heure souhaitée : ${data.get("time")}`,`Nom : ${data.get("name")}`,`Téléphone : ${data.get("phone")}`,note?`Précision : ${note}`:"", "Merci de me confirmer si ce créneau est disponible."].filter(Boolean).join("\n");
    if(/^\d{8,15}$/.test(SALON_WHATSAPP_NUMBER)&&!SALON_WHATSAPP_NUMBER.includes("X")){
      window.open(`https://wa.me/${SALON_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,"_blank","noopener,noreferrer");
      feedback.hidden=false;feedback.textContent="Votre demande est prête dans WhatsApp. Envoyez le message pour que le salon puisse confirmer le créneau.";
    }else{
      feedback.hidden=false;
      feedback.textContent=`Aperçu de la demande (démo uniquement) : ${data.get("service")} · ${dateLabel} à ${data.get("time")} · ${data.get("name")}. En version réelle, cette demande sera envoyée au salon pour confirmation. Aucun rendez-vous n’a été enregistré.`;
    }
  });
}
